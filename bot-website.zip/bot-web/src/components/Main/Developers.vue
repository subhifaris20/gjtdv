<script setup>
import Developer from "./Developer.vue";
</script>

<template>
  <hr />
  <section class="p-12 bg-slate-600">
    <div>
      <div class="text-5xl text-center">Team Members</div>
    </div>
    <div
      class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 place-items-center"
    >
      <Developer
        Name="7RB#3992"
        ID="816336815606071316"
        imgLink="https://i.im.ge/2022/08/22/OiM20S.6a0ec5b20065dd01b438e211b0daa509.jpg"
        Role="Founder"
      />
    </div>
  </section>
</template>
