<template>
  <hr />
  <footer
    class="grid grid-cols-1 md:grid-cols-2 place-items-center p-3 bg-slate-500"
  >
    <div>Developed by Termin#3384</div>
    <div>2022 All rights reserved</div>
  </footer>
</template>
