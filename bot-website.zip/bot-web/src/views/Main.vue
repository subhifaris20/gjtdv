<script setup>
import Hero from "@/components/Main/Hero.vue";
import Developers from "@/components/Main/Developers.vue";
import About from "@/components/Main/About.vue";
</script>

<template>
  <Hero />
  <About />
  <Developers />
</template>
