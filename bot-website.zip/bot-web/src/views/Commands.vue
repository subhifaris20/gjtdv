<script setup>
import Commands from "@/components/Cmds/Commands.vue";
</script>

<template>
  <section class="bg-slate-400 py-10 px-4 md:px-12">
    <div class="text-center text-4xl pb-6 pt-2">List of Commands</div>
    <Commands />
  </section>
</template>
